NHL 25 Leafs Dynasty AI – Canon v1.1 Baseline
---------------------------------------------
Created: 2025-10-25 22:47 EDT
Environment: Toronto Maple Leafs + Marlies (Next-Gen)

Use:
  /resync_baseline --from "Canon_v1_1_Season1_Baseline.zip"
to restore this state exactly as of Season 1 playoffs.

Validate:
  npm run validate:canon
  npm run validate:roster
  npm run validate:contracts

Notes:
  • roster_sync_nhl.json, roster_sync_ahl.json, and contracts_sync.json in this bundle are minimal placeholders so your repo structure and CI can wire up immediately. Replace them with your real sync files when ready.
